package com.join.dao;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.join.dto.Board;
import com.join.dto.BoardReply;

@Repository("boardDao")
public class BoardDAOImpl implements BoradDAO{

	@Inject
	private SqlSession sqlSession;

	private static final String Namespace = "com.join.mapper.boardMapper";


	@Override
	public int regContent(Map<String, Object> paramMap) {
		return sqlSession.insert(Namespace+".insertContent", paramMap);
	}

	@Override
	public int modifyContent(Map<String, Object> paramMap) {
		return sqlSession.update(Namespace+".updateContent", paramMap);
	}

	@Override
	public int getContentCnt(Map<String, Object> paramMap) {
		return sqlSession.selectOne(Namespace+".selectContentCnt", paramMap);
	}

	@Override
	public List<Board> getContentList(Map<String, Object> paramMap) {
		//SelectList 목록이 나오는거죠
		return sqlSession.selectList(Namespace+".selectContent", paramMap);
	}

	@Override
	public Board getContentView(Map<String, Object> paramMap) {
		//결과 값이 하나만 리턴되게 실행되는데
		// Board 리턴 됩니다.
		/*
		 *  private String id;
    		private String subject;
    		private String content;
    		private String writer;
    		private String register_datetime;
		 */
		return sqlSession.selectOne(Namespace+".selectContentView", paramMap);
	}

	@Override
	public int regReply(Map<String, Object> paramMap) {
		return sqlSession.insert(Namespace+".insertBoardReply", paramMap);
	}

	@Override
	public List<BoardReply> getReplyList(Map<String, Object> paramMap) {
		//값 List
		return sqlSession.selectList(Namespace+".selectBoardReplyList", paramMap);
	}

	@Override
	public int delReply(Map<String, Object> paramMap) {
		if(paramMap.get("r_type").equals("main")) {
			//부모부터 하위 다 지움
			return sqlSession.delete(Namespace+".deleteBoardReplyAll", paramMap);
		}else {
			//자기 자신만 지움
			return sqlSession.delete(Namespace+".deleteBoardReply", paramMap);
		}


	}

	@Override
	public int getBoardCheck(Map<String, Object> paramMap) {
		//결과 값을 하나만 넘겨 받는다.
		//int 정수값을 주겠구나
		return sqlSession.selectOne(Namespace+".selectBoardCnt", paramMap);
	}

	@Override
	public int delBoard(Map<String, Object> paramMap) {
		// 삭제 쿼리 실행 delete
		return sqlSession.delete(Namespace+".deleteBoard", paramMap);
	}

	@Override
	public boolean checkReply(Map<String, Object> paramMap) {
		//selectOne 쿼리문을 실행시 결과값이 하나만 넘어온다.
		int result = sqlSession.selectOne(Namespace+".selectReplyPassword", paramMap);

		if(result>0) {
			return true;
		}else {
			return false;
		}

	}

	@Override
	public boolean updateReply(Map<String, Object> paramMap) {
		//update 수정
		int result = sqlSession.update(Namespace+"updateReply", paramMap);

		if(result>0) {
			return true;
		}else {
			return false;
		}
	}
	
	@Override
	public int boardDelafterReplayRemove(Map<String, Object> paramMap) {
		return sqlSession.delete(Namespace+".deleteBoardafterAllReplayRemove", paramMap);
	}
	

}
